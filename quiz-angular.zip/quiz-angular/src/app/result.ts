export class Result {
    id:number;
    score:number;
    grade:string;
    remark:string;
}
