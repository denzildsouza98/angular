export class Answer {
}
